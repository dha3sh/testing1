This is a simple Portfolio.
Steps to follow:
    1)Download the zip file in to local system.
    2)Extract all the files and folders into your system.
    3)Then run the index file by double clicking on it.
